\
import * as React from "react";
import clsx from "clsx";

type BadgeProps = React.HTMLAttributes<HTMLSpanElement> & { variant?: "default" | "secondary" | "outline" };

export function Badge({ className, variant="default", ...props }: BadgeProps) {
  const variants = {
    default: "bg-black text-white",
    secondary: "bg-neutral-100 text-neutral-800",
    outline: "border border-neutral-300 text-neutral-700"
  } as const;
  return <span className={clsx("inline-flex items-center gap-1 px-2 py-1 rounded-xl text-xs", variants[variant], className)} {...props} />;
}

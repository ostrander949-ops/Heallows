\
# Heallows (Next.js + Tailwind)

Gifts that feel like presence — gentle care for body, mind, and soul.

## Getting Started
```bash
npm i
npm run dev
# open http://localhost:3000
```

## Deploy
1. Push to GitHub.
2. Import the repo in Vercel → Deploy (Next.js preset).

## Notes
- TailwindCSS is configured; UI primitives live in `components/ui`.
- Icons: lucide-react. Animations: framer-motion.

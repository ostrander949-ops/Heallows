\
"use client";

import React from "react";
import { motion } from "framer-motion";
import { Heart, Sparkles, Leaf, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardFooter, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Page() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-50 to-white text-neutral-900">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-neutral-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-2 text-lg font-semibold">
              <Sparkles className="h-5 w-5" /> Heallows
            </span>
            <Badge variant="secondary" className="ml-2">Care · Memory · Spirit</Badge>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#comfort" className="hover:text-neutral-600">Comfort</a>
            <a href="#memory" className="hover:text-neutral-600">Memory</a>
            <a href="#spirit" className="hover:text-neutral-600">Spirit</a>
            <a href="#about" className="hover:text-neutral-600">About</a>
          </nav>
          <div className="flex items-center gap-2">
            <Button className="rounded-2xl">Explore Care</Button>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 opacity-80">
          <div className="absolute -top-24 -left-24 h-72 w-72 bg-gradient-to-tr from-neutral-200/50 via-neutral-100/60 to-indigo-100/40 blur-3xl rounded-full" />
          <div className="absolute -bottom-32 -right-16 h-80 w-80 bg-gradient-to-br from-neutral-100/60 via-rose-100/40 to-indigo-100/30 blur-3xl rounded-full" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-24">
          <motion.h1
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-extrabold tracking-tight"
          >
            When love wants to be closer
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-4 max-w-3xl text-lg text-neutral-700"
          >
            Heallows creates gentle, personalized gifts for moments that ask for extra care — surgery, treatment, hospice, or any time comfort is needed. Each piece carries warmth and meaning.
          </motion.p>
        </div>
      </section>

      <section id="about" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="rounded-3xl border bg-white/70 p-6">
          <h2 className="text-2xl font-bold">Our care standards</h2>
          <div className="mt-4 grid md:grid-cols-3 gap-6">
            {[
              { Icon: ShieldCheck, title: "Respectful Language", text: "We write with sensitivity and avoid euphemisms that hide reality." },
              { Icon: Heart, title: "Consent & Privacy", text: "Messages and blessings are kept private and shared only as directed." },
              { Icon: Leaf, title: "Gentle Materials", text: "Soft, skin-kind fabrics and mindful sourcing." }
            ].map((f) => (
              <Card key={f.title} className="rounded-2xl border-neutral-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <f.Icon className="h-5 w-5" /> {f.title}
                  </CardTitle>
                  <CardDescription>{f.text}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-neutral-200">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 text-sm text-neutral-600 grid md:grid-cols-3 gap-6">
          <div>
            <div className="font-semibold flex items-center gap-2"><Sparkles className="h-4 w-4" /> Heallows</div>
            <p className="mt-2">Carefully-made gifts for healing, hospice, and recovery.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="font-semibold">Shop</div>
              <ul className="mt-2 space-y-1">
                <li><a href="#comfort" className="hover:text-neutral-800">Comfort</a></li>
                <li><a href="#memory" className="hover:text-neutral-800">Memory</a></li>
                <li><a href="#spirit" className="hover:text-neutral-800">Spirit</a></li>
              </ul>
            </div>
            <div>
              <div className="font-semibold">Company</div>
              <ul className="mt-2 space-y-1">
                <li><a href="#about" className="hover:text-neutral-800">About</a></li>
                <li><a href="#" className="hover:text-neutral-800">Care Promise</a></li>
                <li><a href="#" className="hover:text-neutral-800">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="md:text-right">
            <div>© {new Date().getFullYear()} Heallows. All rights reserved.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
